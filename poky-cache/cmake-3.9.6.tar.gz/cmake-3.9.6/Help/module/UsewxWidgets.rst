.. cmake-module:: ../../Modules/UsewxWidgets.cmake
